from .analysis import Univariate, Bivariate, Dataset
from DataExploration import analysis